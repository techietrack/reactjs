import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Cart from "./Cart";

const dishesList = [
  { id: 1, name: "Vada", price: 10, qty: 0, path: "./vada.png" },
  { id: 2, name: "Bajji", price: 15, qty: 0, path: "./bajji.png" },
  { id: 3, name: "Bonda", price: 20, qty: 0, path: "./bonda.png" },
];

function App() {
  return (
    <div className="container">
      <Cart loadList={dishesList} />
    </div>
  );
}

export default App;
