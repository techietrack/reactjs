import React, { useState, useEffect } from "react";
import CartItem from "./CartItem";
import "./Cart.css";
function Cart({ loadList }) {
  const [dishes, setItems] = useState(loadList);
  const updateQty = (id, newQty) => {
    console.log("Items count Updated");
    const newItems = dishes.map((item) => {
      if (item.id === id) {
        return { ...item, qty: newQty };
      }
      return item;
    });
    setItems(newItems);
  };
  const grandTotal = dishes
    .reduce((total, item) => total + item.qty * item.price, 0)
    .toFixed(2);
  return (
    <div className="Cart">
      <img src="./banner.png" />
      <h1 className="Cart-title">Snacks bar</h1>
      <div className="Cart-dishes">
        {dishes.map((item) => (
          <CartItem key={item.id} updateQty={updateQty} {...item} />
        ))}
      </div>
      <h2 className="Cart-total">Grand Total (Rs): {grandTotal}</h2>
    </div>
  );
}
export default Cart;
