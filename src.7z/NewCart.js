import React, { useState, useEffect } from "react";
import CartItem from "./NewCartItem";
import "./Cart.css";

function Cart({ initialItems }) {
  const updateQty = (chQty) => {
    const newCount = chQty;
    console.log("Items count changed");
    setCount(newCount);
  };

  const [count, setCounter] = useState(0);
  const setCount = (count) => {
    console.log("Set items count value");
    setCounter(count);
  };

  return (
    <div className="Cart">
      <img src="./banner.png" />
      <h1 className="Cart-title">Vada kadai</h1>
      <div className="Cart-items">
        <div>
          <CartItem changeQty={updateQty} count={count} />
        </div>
      </div>
      <h2 className="Cart-total">Grand Total (Rs):</h2>
    </div>
  );
}
export default Cart;
