import React from "react";
import "./CartItem.css";

function NewCartItem({ changeQty, count }) {
  const addOne = () => changeQty(count + 1);
  const subtractOne = () => changeQty(count - 1);
  return (
    <div className="CartItem">
      <div>
        <img src="./bajji.png" />
      </div>
      <div className="item-name">Baji</div>
      <div>Rs: 10</div>
      <div>
        <button onClick={subtractOne}>-</button>
        {count}
        <button onClick={addOne}>+</button>
      </div>
      <div>Total (Rs): </div>
    </div>
  );
}

export default NewCartItem;
