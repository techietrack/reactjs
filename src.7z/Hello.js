import React from "react";

function Hello() {
  return (
    <div>
      <h1>Hello Coder</h1>
      <p>How are you</p>
    </div>
  );
}

export default Hello;
